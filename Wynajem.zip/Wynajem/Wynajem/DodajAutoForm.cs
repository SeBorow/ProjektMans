﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wynajem
{
    public partial class DodajAutoForm : Form
    {
        public class DanePojazdu
        {
            public string Marka { get; set; }

            public string Model { get; set; }
            public string Kolor { get; set; }
            public string NumerRejestracyjny { get; set; }
        }

        public DanePojazdu NowyPojazd { get; private set; }

        public DodajAutoForm()
        {
            InitializeComponent();
            this.Text = "Dodaj Auto.";
        }

        private void BtnZapisz_Click(object sender, EventArgs e)
        {
            string marka = txtRubryka1.Text;
            string model = txtRubryka2.Text;
            string kolor = txtRubryka3.Text;
            string numerRejestracyjny = txtRubryka4.Text;

            NowyPojazd = new DanePojazdu
            {
                Marka = marka,
                Model = model,
                Kolor = kolor,
                NumerRejestracyjny = numerRejestracyjny
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private void txtRubryka1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtRubryka4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void DodajAutoForm_Load(object sender, EventArgs e)
        {
            
        }
    }
}

