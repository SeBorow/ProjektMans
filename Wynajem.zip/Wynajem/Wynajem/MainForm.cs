﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Wynajem
{
    public partial class MainForm : Form
    {
        private Form1 loginForm; // Deklarujemy referencję do okna logowania

        public MainForm()
        {
            InitializeComponent();
            this.Text = "Car Management";

            buttonWyloguj.Click += new EventHandler(buttonWyloguj_Click); // Przypisanie funkcji obsługi kliknięcia do przycisku "Wyloguj"

            loginForm = new Form1(); // Inicjalizacja
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            WczytajDaneZPliku("dane_aut.txt");
            listViewAutos.FullRowSelect = true;
            listViewAutos.View = View.Details; //zaznacza całą linie w bazie danych
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ZapiszDaneDoPliku("dane_aut.txt");
            Application.Exit(); //zamyka cala apke po zamkniecuy MainForm - wczesniej mimo, ze zamykalem okno to apka dalej dzialal w tle i trzeba bylo ja zamykac z menadzera
        }

        private int numerPorzadkowy = 1; // Inicjalizacja numeru porządkowego

        private void buttonDodaj(object sender, EventArgs e)
        {
            DodajAutoForm dodajAutoForm = new DodajAutoForm();
            dodajAutoForm.ShowDialog();

            if (dodajAutoForm.DialogResult == DialogResult.OK)
            {
                DodajAutoForm.DanePojazdu danePojazdu = dodajAutoForm.NowyPojazd; // Pobieranie danych pojazdu z nowej właściwości NowyPojazd

                int highestNumerPorzadkowy = 0;

                if (listViewAutos.Items.Count > 0)
                {
                    highestNumerPorzadkowy = int.Parse(listViewAutos.Items[listViewAutos.Items.Count - 1].Text);
                }

                ListViewItem newItem = new ListViewItem((highestNumerPorzadkowy + 1).ToString());
                newItem.SubItems.Add(danePojazdu.Marka); // Dodawanie poszczególnych danych pojazdu jako SubItems

                // Dodawanie pozostałych danych pojazdu do ListViewItem
                newItem.SubItems.Add(danePojazdu.Model);
                newItem.SubItems.Add(danePojazdu.Kolor);
                newItem.SubItems.Add(danePojazdu.NumerRejestracyjny);

                listViewAutos.Items.Add(newItem);
            }
        }

        private void ZapiszDaneDoPliku(string nazwaPliku)
        {
            using (StreamWriter file = new StreamWriter(nazwaPliku))
            {
                foreach (ListViewItem item in listViewAutos.Items)
                {
                    file.WriteLine($"{item.SubItems[0].Text},{item.SubItems[1].Text},{item.SubItems[2].Text},{item.SubItems[3].Text},{item.SubItems[4].Text}");
                }
            }
        }

        private void WczytajDaneZPliku(string nazwaPliku)
        {
            if (File.Exists(nazwaPliku))
            {
                string[] lines = File.ReadAllLines(nazwaPliku);
                foreach (string line in lines)
                {
                    string[] elements = line.Split(',');
                    ListViewItem newItem = new ListViewItem(elements);
                    listViewAutos.Items.Add(newItem);
                }
            }
        }


        private void listViewAutos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MainForm_Resize(object sender, EventArgs e)
        {

            int nowaSzerokosc = this.ClientSize.Width;
            int nowaWysokosc = this.ClientSize.Height;


            listViewAutos.Width = nowaSzerokosc - 20; // Przykładowe dostosowanie szerokości kontrolki
            listViewAutos.Height = nowaWysokosc - 50; // Przykładowe dostosowanie wysokości kontrolki



        }

        private void buttonEdytuj_Click(object sender, EventArgs e)
        {
            if (listViewAutos.SelectedItems.Count > 0)
            {
                // Pobierz zaznaczony element z ListView
                ListViewItem selected = listViewAutos.SelectedItems[0];

                // Pobierz dane zaznaczonego samochodu
                string marka = selected.SubItems[1].Text; // Marka
                string model = selected.SubItems[2].Text; // Model
                string kolor = selected.SubItems[3].Text; // Kolor
                string numerRejestracyjny = selected.SubItems[4].Text; // Numer rejestracyjny

                // Utwórz formularz EdytujAutoForm i przekaż dane zaznaczonego samochodu
                EdytujAutoForm edytujAutoForm = new EdytujAutoForm(marka, model, kolor, numerRejestracyjny);
                if (edytujAutoForm.ShowDialog() == DialogResult.OK)
                {
                    selected.SubItems[1].Text = edytujAutoForm.EdytowanaMarka; // Aktualizacja marki
                    selected.SubItems[2].Text = edytujAutoForm.EdytowanyModel; // Aktualizacja modelu
                    selected.SubItems[3].Text = edytujAutoForm.EdytowanyKolor; // Aktualizacja koloru
                    selected.SubItems[4].Text = edytujAutoForm.EdytowanyNumerRejestracyjny; // Aktualizacja numeru rejestracyjnego
                }
            }
            else
            {
                MessageBox.Show("Wybierz auto do edycji.");
            }
        }

        private void AktualizujNumeracje()
        {
            for (int i = 0; i < listViewAutos.Items.Count; i++)
            {
                listViewAutos.Items[i].Text = (i + 1).ToString();
            }
        }

        private void buttonUsun_Click(object sender, EventArgs e)
        {
            if (listViewAutos.SelectedItems.Count > 0)
            {
                DialogResult dialogResult = MessageBox.Show("Czy na pewno chcesz usunąć zaznaczone auto?", "Potwierdź usunięcie", MessageBoxButtons.OKCancel);

                if (dialogResult == DialogResult.OK)
                {
                    int[] selectedIndices = listViewAutos.SelectedIndices.Cast<int>().ToArray();
                    foreach (int index in selectedIndices)
                    {
                        listViewAutos.Items.RemoveAt(index);
                    }

                    AktualizujNumeracje(); // Aktualizacja numeracji po usunięciu
                }
            }
            else
            {
                MessageBox.Show("Wybierz auto do usunięcia.");
            }
        }

        private void buttonWyloguj_Click(object sender, EventArgs e)
        {
            // Ukryj bieżące okno (MainForm)
            this.Hide();

            // Pokaż okno logowania, jeśli nie jest widoczne
            if (!loginForm.Visible)
            {
                loginForm.Show();
            }
        }

        private void buttonRezerwacja_Click(object sender, EventArgs e)
        {
            if (listViewAutos.SelectedItems.Count > 0)
            {
                DodajRezerwacjeForm dodajRezerwacjeForm = new DodajRezerwacjeForm();

                // Dodanie obsługi zdarzenia RezerwacjaZapisana
                dodajRezerwacjeForm.RezerwacjaZapisana += DodajRezerwacjeForm_RezerwacjaZapisana;

                if (dodajRezerwacjeForm.ShowDialog() == DialogResult.OK)
                {
                    // Logika po zapisaniu rezerwacji (jeśli potrzebna)
                }
            }
            else
            {
                MessageBox.Show("Wybierz auto do zarezerwowania.");
            }
        }

        private void DodajRezerwacjeForm_RezerwacjaZapisana(object sender, EventArgs e)
        {
            // Aktualizacja stanu rezerwacji w listViewAutos na "zarezerwowane"
            if (listViewAutos.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listViewAutos.SelectedItems[0];
                selectedItem.SubItems.Add("Zarezerwowane"); // Dodanie stanu rezerwacji jako SubItem
            }
        }

        private void buttonUsunRezerwacje_Click(object sender, EventArgs e)
        {
            if (listViewAutos.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listViewAutos.SelectedItems[0];

                // Sprawdzamy, czy wybrany element ma zaznaczony status "Zarezerwowane"
                if (selectedItem.SubItems.Count > 5 && selectedItem.SubItems[5].Text == "Zarezerwowane")
                {
                    selectedItem.SubItems.RemoveAt(5); // Usuwanie statusu "Zarezerwowane" z listy subitemów
                                                       
                                                       
                }
                else
                {
                    MessageBox.Show("Ten pojazd nie jest zarezerwowany.");
                }
            }
            else
            {
                MessageBox.Show("Wybierz auto, aby usunąć rezerwację.");
            }
        }
    }
}