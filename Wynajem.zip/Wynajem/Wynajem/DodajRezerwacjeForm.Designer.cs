﻿namespace Wynajem
{
    partial class DodajRezerwacjeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajRezerwacjeForm));
            this.textBoxImie = new System.Windows.Forms.TextBox();
            this.textBoxNazw = new System.Windows.Forms.TextBox();
            this.textBoxNumer = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBoxMOdb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonZapiszRezerwacje = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxMZwr = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxImie
            // 
            this.textBoxImie.Location = new System.Drawing.Point(313, 159);
            this.textBoxImie.Name = "textBoxImie";
            this.textBoxImie.Size = new System.Drawing.Size(243, 20);
            this.textBoxImie.TabIndex = 0;
            // 
            // textBoxNazw
            // 
            this.textBoxNazw.Location = new System.Drawing.Point(313, 185);
            this.textBoxNazw.Name = "textBoxNazw";
            this.textBoxNazw.Size = new System.Drawing.Size(243, 20);
            this.textBoxNazw.TabIndex = 1;
            // 
            // textBoxNumer
            // 
            this.textBoxNumer.Location = new System.Drawing.Point(313, 212);
            this.textBoxNumer.Name = "textBoxNumer";
            this.textBoxNumer.Size = new System.Drawing.Size(243, 20);
            this.textBoxNumer.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(313, 293);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(243, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // comboBoxMOdb
            // 
            this.comboBoxMOdb.FormattingEnabled = true;
            this.comboBoxMOdb.Items.AddRange(new object[] {
            "Salon Toruńska",
            "Salon Puławska",
            "Salon Aleje Jerozolimskie"});
            this.comboBoxMOdb.Location = new System.Drawing.Point(313, 238);
            this.comboBoxMOdb.Name = "comboBoxMOdb";
            this.comboBoxMOdb.Size = new System.Drawing.Size(243, 21);
            this.comboBoxMOdb.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(278, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Imię:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(251, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nazwisko:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(238, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nr. Telefonu:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(221, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Miejsce Odbioru:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(189, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Data Rezerwacji:";
            // 
            // buttonZapiszRezerwacje
            // 
            this.buttonZapiszRezerwacje.Location = new System.Drawing.Point(373, 362);
            this.buttonZapiszRezerwacje.Name = "buttonZapiszRezerwacje";
            this.buttonZapiszRezerwacje.Size = new System.Drawing.Size(106, 23);
            this.buttonZapiszRezerwacje.TabIndex = 10;
            this.buttonZapiszRezerwacje.Text = "Zapisz Rezerwację";
            this.buttonZapiszRezerwacje.UseVisualStyleBackColor = true;
            this.buttonZapiszRezerwacje.Click += new System.EventHandler(this.buttonZapiszRezerwacje_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(313, 319);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(243, 20);
            this.dateTimePicker2.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.Location = new System.Drawing.Point(283, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Od:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label7.Image = ((System.Drawing.Image)(resources.GetObject("label7.Image")));
            this.label7.Location = new System.Drawing.Point(283, 326);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Do:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label7.UseMnemonic = false;
            // 
            // comboBoxMZwr
            // 
            this.comboBoxMZwr.FormattingEnabled = true;
            this.comboBoxMZwr.Items.AddRange(new object[] {
            "Salon Toruńska",
            "Salon Puławska",
            "Salon Aleje Jerozolimskie"});
            this.comboBoxMZwr.Location = new System.Drawing.Point(313, 266);
            this.comboBoxMZwr.Name = "comboBoxMZwr";
            this.comboBoxMZwr.Size = new System.Drawing.Size(243, 21);
            this.comboBoxMZwr.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Image = ((System.Drawing.Image)(resources.GetObject("label8.Image")));
            this.label8.Location = new System.Drawing.Point(225, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Miejsce Zwrotu:";
            // 
            // DodajRezerwacjeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBoxMZwr);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.buttonZapiszRezerwacje);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxMOdb);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBoxNumer);
            this.Controls.Add(this.textBoxNazw);
            this.Controls.Add(this.textBoxImie);
            this.Name = "DodajRezerwacjeForm";
            this.Text = "DodajRezerwacjeForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxImie;
        private System.Windows.Forms.TextBox textBoxNazw;
        private System.Windows.Forms.TextBox textBoxNumer;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBoxMOdb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonZapiszRezerwacje;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxMZwr;
        private System.Windows.Forms.Label label8;
    }
}