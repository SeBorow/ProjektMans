﻿namespace Wynajem
{
    partial class Form1
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonZaloguj = new System.Windows.Forms.Button();
            this.textBoxLogin = new System.Windows.Forms.TextBox();
            this.textBoxHaslo = new System.Windows.Forms.TextBox();
            this.label1Login = new System.Windows.Forms.Label();
            this.label2Haslo = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // buttonZaloguj
            // 
            this.buttonZaloguj.Location = new System.Drawing.Point(351, 232);
            this.buttonZaloguj.Name = "buttonZaloguj";
            this.buttonZaloguj.Size = new System.Drawing.Size(75, 23);
            this.buttonZaloguj.TabIndex = 0;
            this.buttonZaloguj.Text = "Zaloguj";
            this.buttonZaloguj.UseVisualStyleBackColor = true;
            this.buttonZaloguj.Click += new System.EventHandler(this.Zaloguj_Click);
            // 
            // textBoxLogin
            // 
            this.textBoxLogin.Location = new System.Drawing.Point(341, 166);
            this.textBoxLogin.Name = "textBoxLogin";
            this.textBoxLogin.Size = new System.Drawing.Size(100, 20);
            this.textBoxLogin.TabIndex = 1;
            // 
            // textBoxHaslo
            // 
            this.textBoxHaslo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxHaslo.Location = new System.Drawing.Point(341, 192);
            this.textBoxHaslo.Name = "textBoxHaslo";
            this.textBoxHaslo.Size = new System.Drawing.Size(100, 20);
            this.textBoxHaslo.TabIndex = 2;
            this.textBoxHaslo.TextChanged += new System.EventHandler(this.TextBox2_TextChanged);
            // 
            // label1Login
            // 
            this.label1Login.AutoSize = true;
            this.label1Login.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label1Login.Image = ((System.Drawing.Image)(resources.GetObject("label1Login.Image")));
            this.label1Login.Location = new System.Drawing.Point(300, 169);
            this.label1Login.Name = "label1Login";
            this.label1Login.Size = new System.Drawing.Size(36, 13);
            this.label1Login.TabIndex = 3;
            this.label1Login.Text = "Login:";
            this.label1Login.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2Haslo
            // 
            this.label2Haslo.AutoSize = true;
            this.label2Haslo.Image = ((System.Drawing.Image)(resources.GetObject("label2Haslo.Image")));
            this.label2Haslo.Location = new System.Drawing.Point(300, 195);
            this.label2Haslo.Name = "label2Haslo";
            this.label2Haslo.Size = new System.Drawing.Size(39, 13);
            this.label2Haslo.TabIndex = 4;
            this.label2Haslo.Text = "Hasło:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(817, 467);
            this.Controls.Add(this.label2Haslo);
            this.Controls.Add(this.label1Login);
            this.Controls.Add(this.textBoxHaslo);
            this.Controls.Add(this.textBoxLogin);
            this.Controls.Add(this.buttonZaloguj);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Resize);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonZaloguj;
        private System.Windows.Forms.TextBox textBoxLogin;
        private System.Windows.Forms.TextBox textBoxHaslo;
        private System.Windows.Forms.Label label1Login;
        private System.Windows.Forms.Label label2Haslo;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

