﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wynajem
{
    public partial class DodajRezerwacjeForm : Form
    {
        public class DaneRezerwacji
        {
            public string Imie { get; set; }
            public string Nazwisko { get; set; }
            public string NrTelefonu { get; set; }
            public string MiejsceOdbioru { get; set; }
            public string MiejsceZwrotu { get; set; }
            public DateTime DataOd { get; set; }
            public DateTime DataDo { get; set; }
        }

        public event EventHandler RezerwacjaZapisana;

        private List<DaneRezerwacji> listaRezerwacji = new List<DaneRezerwacji>();

        public DodajRezerwacjeForm()
        {
            InitializeComponent();
            this.Text = "Dodaj Rezerwację.";
        }

        private void buttonZapiszRezerwacje_Click(object sender, EventArgs e)
        {
            string imie = textBoxImie.Text;
            string nazwisko = textBoxNazw.Text;
            string nrTelefonu = textBoxNumer.Text;
            string miejsceOdbioru = comboBoxMOdb.Text;
            string miejsceZwrotu = comboBoxMZwr.Text;
            DateTime dataOd = dateTimePicker1.Value;
            DateTime dataDo = dateTimePicker2.Value;

            DaneRezerwacji nowaRezerwacja = new DaneRezerwacji
            {
                Imie = imie,
                Nazwisko = nazwisko,
                NrTelefonu = nrTelefonu,
                MiejsceOdbioru = miejsceOdbioru,
                MiejsceZwrotu = miejsceZwrotu,
                DataOd = dataOd,
                DataDo = dataDo
            };

            listaRezerwacji.Add(nowaRezerwacja);

            MessageBox.Show("Rezerwacja została zapisana!");

            RezerwacjaZapisana?.Invoke(this, EventArgs.Empty);

            this.DialogResult = DialogResult.OK;
            this.Close();
        

        }
    }
} 
