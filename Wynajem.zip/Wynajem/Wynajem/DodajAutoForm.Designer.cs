﻿namespace Wynajem
{
    partial class DodajAutoForm
    {
 
        private System.ComponentModel.IContainer components = null;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code


        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajAutoForm));
            this.btnZapisz = new System.Windows.Forms.Button();
            this.txtRubryka1 = new System.Windows.Forms.TextBox();
            this.txtRubryka2 = new System.Windows.Forms.TextBox();
            this.txtRubryka3 = new System.Windows.Forms.TextBox();
            this.txtRubryka4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnZapisz
            // 
            this.btnZapisz.Location = new System.Drawing.Point(385, 194);
            this.btnZapisz.Name = "btnZapisz";
            this.btnZapisz.Size = new System.Drawing.Size(75, 23);
            this.btnZapisz.TabIndex = 0;
            this.btnZapisz.Text = "Zapisz";
            this.btnZapisz.UseVisualStyleBackColor = true;
            this.btnZapisz.Click += new System.EventHandler(this.BtnZapisz_Click);
            // 
            // txtRubryka1
            // 
            this.txtRubryka1.Location = new System.Drawing.Point(291, 78);
            this.txtRubryka1.Name = "txtRubryka1";
            this.txtRubryka1.Size = new System.Drawing.Size(291, 20);
            this.txtRubryka1.TabIndex = 1;
            this.txtRubryka1.TextChanged += new System.EventHandler(this.txtRubryka1_TextChanged);
            // 
            // txtRubryka2
            // 
            this.txtRubryka2.Location = new System.Drawing.Point(291, 104);
            this.txtRubryka2.Name = "txtRubryka2";
            this.txtRubryka2.Size = new System.Drawing.Size(291, 20);
            this.txtRubryka2.TabIndex = 2;
            // 
            // txtRubryka3
            // 
            this.txtRubryka3.Location = new System.Drawing.Point(291, 130);
            this.txtRubryka3.Name = "txtRubryka3";
            this.txtRubryka3.Size = new System.Drawing.Size(291, 20);
            this.txtRubryka3.TabIndex = 3;
            // 
            // txtRubryka4
            // 
            this.txtRubryka4.Location = new System.Drawing.Point(291, 156);
            this.txtRubryka4.Name = "txtRubryka4";
            this.txtRubryka4.Size = new System.Drawing.Size(291, 20);
            this.txtRubryka4.TabIndex = 4;
            this.txtRubryka4.TextChanged += new System.EventHandler(this.txtRubryka4_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(249, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Marka:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(251, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Model:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(251, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Kolor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(178, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Numer Rejestracyjny:";
            // 
            // DodajAutoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(914, 464);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRubryka4);
            this.Controls.Add(this.txtRubryka3);
            this.Controls.Add(this.txtRubryka2);
            this.Controls.Add(this.txtRubryka1);
            this.Controls.Add(this.btnZapisz);
            this.Name = "DodajAutoForm";
            this.Text = "DodajAutoForm";
            this.Load += new System.EventHandler(this.DodajAutoForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnZapisz;
        private System.Windows.Forms.TextBox txtRubryka1;
        private System.Windows.Forms.TextBox txtRubryka2;
        private System.Windows.Forms.TextBox txtRubryka3;
        private System.Windows.Forms.TextBox txtRubryka4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}