﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wynajem
{
    internal static class Program
    {
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Form1 loginForm = new Form1(); //tworzymy login, reszte zrobi sie na MainForm
            Application.Run(loginForm); 
        }
    }
}
