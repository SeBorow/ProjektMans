﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wynajem
{
    public partial class EdytujAutoForm : Form
    {
        // Deklaracja właściwości do przechowywania danych
        public string EdytowanaMarka { get; set; }
        public string EdytowanyModel { get; set; }
        public string EdytowanyKolor { get; set; }
        public string EdytowanyNumerRejestracyjny { get; set; }

        // Konstruktor przyjmujący 4 argumenty
        public EdytujAutoForm(string marka, string model, string kolor, string numerRejestracyjny)
        {
            InitializeComponent();
            this.Text = "Edytuj Auto.";

            // Przypisanie wartości do właściwości
            EdytowanaMarka = marka;
            EdytowanyModel = model;
            EdytowanyKolor = kolor;
            EdytowanyNumerRejestracyjny = numerRejestracyjny;

            // Tutaj możemy umieścić kod do wyświetlenia wartości w kontrolkach formularza
        }

        private void buttonZapisz_Click(object sender, EventArgs e)
        {
            // Pobieramy zaktualizowane dane z pól tekstowych lub kontrolki TextBox w EdytujAutoForm
            string nowaMarka = textBox1.Text;
            string nowyModel = textBox2.Text;
            string nowyKolor = textBox3.Text;
            string nowyNumerRejestracyjny = textBox4.Text;

            // Zapisujemy zaktualizowane dane w właściwościach EdytujAutoForm
            EdytowanaMarka = nowaMarka;
            EdytowanyModel = nowyModel;
            EdytowanyKolor = nowyKolor;
            EdytowanyNumerRejestracyjny = nowyNumerRejestracyjny;

            // Ustawiamy DialogResult na OK, aby potwierdzić zapis i zamkniąć formularza
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void EdytujAutoForm_Load(object sender, EventArgs e)
        {

        }
    }
}
