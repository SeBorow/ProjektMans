﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Wynajem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Witamy w systemie rezerwacji pojazdów.";
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Zaloguj_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text;
            string haslo = textBoxHaslo.Text;

            if (login == "a" && haslo == "a")
            {
                MessageBox.Show("Zalogowano pomyślnie.");
                

                
                MainForm mainForm = new MainForm();
                mainForm.Show();

                
                this.Hide();
            }
            else
            {
                MessageBox.Show("Błędny login lub hasło. Spróbuj ponownie.");
            }
        }


        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            textBoxHaslo.UseSystemPasswordChar = true; 

        }

        private void Form1_Resize(object sender, EventArgs e)  
        {
            int verticalSpacing = 20; 
            int controlsTop = (this.ClientSize.Height - (textBoxLogin.Height * 3 + verticalSpacing * 2)) / 2;

            label1Login.Location = new Point((this.ClientSize.Width - label1Login.Width - textBoxLogin.Width) / 2, controlsTop);
            textBoxLogin.Location = new Point(label1Login.Location.X + label1Login.Width, controlsTop);

            controlsTop += textBoxLogin.Height + verticalSpacing;

            label2Haslo.Location = new Point((this.ClientSize.Width - label2Haslo.Width - textBoxHaslo.Width) / 2, controlsTop);
            textBoxHaslo.Location = new Point(label2Haslo.Location.X + label2Haslo.Width, controlsTop);

            buttonZaloguj.Location = new Point((this.ClientSize.Width - buttonZaloguj.Width) / 2, controlsTop + textBoxHaslo.Height + verticalSpacing);
        }


    }
}