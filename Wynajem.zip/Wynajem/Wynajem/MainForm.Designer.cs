﻿namespace Wynajem
{
    partial class MainForm
    {
    
        private System.ComponentModel.IContainer components = null;

     
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnDodajAuto = new System.Windows.Forms.Button();
            this.listViewAutos = new System.Windows.Forms.ListView();
            this.Rubryka0 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rubryka1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rubryka2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rubryka3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rubryka4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rubryka5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonEdytuj = new System.Windows.Forms.Button();
            this.buttonUsun = new System.Windows.Forms.Button();
            this.buttonWyloguj = new System.Windows.Forms.Button();
            this.buttonRezerwacja = new System.Windows.Forms.Button();
            this.buttonUsunRezerwacje = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnDodajAuto
            // 
            this.btnDodajAuto.Location = new System.Drawing.Point(12, 12);
            this.btnDodajAuto.Name = "btnDodajAuto";
            this.btnDodajAuto.Size = new System.Drawing.Size(131, 23);
            this.btnDodajAuto.TabIndex = 0;
            this.btnDodajAuto.Text = "Dodaj Auto";
            this.btnDodajAuto.UseVisualStyleBackColor = true;
            this.btnDodajAuto.Click += new System.EventHandler(this.buttonDodaj);
            // 
            // listViewAutos
            // 
            this.listViewAutos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Rubryka0,
            this.Rubryka1,
            this.Rubryka2,
            this.Rubryka3,
            this.Rubryka4,
            this.Rubryka5});
            this.listViewAutos.HideSelection = false;
            this.listViewAutos.Location = new System.Drawing.Point(217, 12);
            this.listViewAutos.Name = "listViewAutos";
            this.listViewAutos.Size = new System.Drawing.Size(750, 413);
            this.listViewAutos.TabIndex = 1;
            this.listViewAutos.UseCompatibleStateImageBehavior = false;
            this.listViewAutos.View = System.Windows.Forms.View.Details;
            this.listViewAutos.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // Rubryka0
            // 
            this.Rubryka0.Text = "Nr.";
            // 
            // Rubryka1
            // 
            this.Rubryka1.Text = "Marka";
            this.Rubryka1.Width = 105;
            // 
            // Rubryka2
            // 
            this.Rubryka2.Text = "Model";
            this.Rubryka2.Width = 144;
            // 
            // Rubryka3
            // 
            this.Rubryka3.Text = "Kolor";
            this.Rubryka3.Width = 93;
            // 
            // Rubryka4
            // 
            this.Rubryka4.Text = "Numer Rejestracyjny";
            this.Rubryka4.Width = 191;
            // 
            // Rubryka5
            // 
            this.Rubryka5.Text = "Stan Rezerwacji";
            this.Rubryka5.Width = 125;
            // 
            // buttonEdytuj
            // 
            this.buttonEdytuj.Location = new System.Drawing.Point(12, 41);
            this.buttonEdytuj.Name = "buttonEdytuj";
            this.buttonEdytuj.Size = new System.Drawing.Size(131, 23);
            this.buttonEdytuj.TabIndex = 2;
            this.buttonEdytuj.Text = "Edytuj Auto";
            this.buttonEdytuj.UseVisualStyleBackColor = true;
            this.buttonEdytuj.Click += new System.EventHandler(this.buttonEdytuj_Click);
            // 
            // buttonUsun
            // 
            this.buttonUsun.Location = new System.Drawing.Point(12, 70);
            this.buttonUsun.Name = "buttonUsun";
            this.buttonUsun.Size = new System.Drawing.Size(131, 23);
            this.buttonUsun.TabIndex = 3;
            this.buttonUsun.Text = "Usuń Auto";
            this.buttonUsun.UseVisualStyleBackColor = true;
            this.buttonUsun.Click += new System.EventHandler(this.buttonUsun_Click);
            // 
            // buttonWyloguj
            // 
            this.buttonWyloguj.Location = new System.Drawing.Point(12, 402);
            this.buttonWyloguj.Name = "buttonWyloguj";
            this.buttonWyloguj.Size = new System.Drawing.Size(131, 23);
            this.buttonWyloguj.TabIndex = 4;
            this.buttonWyloguj.Text = "Wyloguj";
            this.buttonWyloguj.UseVisualStyleBackColor = true;
            this.buttonWyloguj.Click += new System.EventHandler(this.buttonWyloguj_Click);
            // 
            // buttonRezerwacja
            // 
            this.buttonRezerwacja.Location = new System.Drawing.Point(12, 99);
            this.buttonRezerwacja.Name = "buttonRezerwacja";
            this.buttonRezerwacja.Size = new System.Drawing.Size(131, 23);
            this.buttonRezerwacja.TabIndex = 5;
            this.buttonRezerwacja.Text = "Dodaj Rezerwację";
            this.buttonRezerwacja.UseVisualStyleBackColor = true;
            this.buttonRezerwacja.Click += new System.EventHandler(this.buttonRezerwacja_Click);
            // 
            // buttonUsunRezerwacje
            // 
            this.buttonUsunRezerwacje.Location = new System.Drawing.Point(12, 128);
            this.buttonUsunRezerwacje.Name = "buttonUsunRezerwacje";
            this.buttonUsunRezerwacje.Size = new System.Drawing.Size(131, 23);
            this.buttonUsunRezerwacje.TabIndex = 6;
            this.buttonUsunRezerwacje.Text = "Usuń Rezerwację";
            this.buttonUsunRezerwacje.UseVisualStyleBackColor = true;
            this.buttonUsunRezerwacje.Click += new System.EventHandler(this.buttonUsunRezerwacje_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1000, 569);
            this.Controls.Add(this.buttonUsunRezerwacje);
            this.Controls.Add(this.buttonRezerwacja);
            this.Controls.Add(this.buttonWyloguj);
            this.Controls.Add(this.buttonUsun);
            this.Controls.Add(this.buttonEdytuj);
            this.Controls.Add(this.listViewAutos);
            this.Controls.Add(this.btnDodajAuto);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDodajAuto;
        private System.Windows.Forms.ListView listViewAutos;
        private System.Windows.Forms.ColumnHeader Rubryka0;
        private System.Windows.Forms.ColumnHeader Rubryka1;
        private System.Windows.Forms.ColumnHeader Rubryka2;
        private System.Windows.Forms.ColumnHeader Rubryka3;
        private System.Windows.Forms.ColumnHeader Rubryka4;
        private System.Windows.Forms.ColumnHeader Rubryka5;
        private System.Windows.Forms.Button buttonEdytuj;
        private System.Windows.Forms.Button buttonUsun;
        private System.Windows.Forms.Button buttonWyloguj;
        private System.Windows.Forms.Button buttonRezerwacja;
        private System.Windows.Forms.Button buttonUsunRezerwacje;
    }
}